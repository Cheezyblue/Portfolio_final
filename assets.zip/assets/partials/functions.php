<?php

	// Constants
	// this ill ensure that our apps will redirect to this website
	define("SITE_URL", "http://localhost");

	function h($str) {
		return htmlspecialchars($str);
	}

?>